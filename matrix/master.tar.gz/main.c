#include <sys/types.h>
#include <sys/mman.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <getopt.h>
#include <dc.h>

#define IN_FILENAME "input.jpg"
#define OUT_FILENAME "output.jpg"

static const struct option longopts[] = { { "config", required_argument, NULL,
		'c' } };

static int maxWus = 0;
static int assimilatedWUs = 0;

// Functions statement -------------------------------------------


void submitWU();
void assimilateResult();
static void waitForResults(void);
static void processResult(DC_Workunit *wu, DC_Result *result);

//argv[0] - executable programm name     argv[1] - configuration file
// ---------------------------------------------------------------------------------------
int main(int argv, char *argc[]) {

	char *DCAPIConfigFile = NULL;

	int c;

	printf("--------- START ------------\nChecking the input parameters\n");

	while ((c = getopt_long(argv, argc, "c:", longopts, NULL)) != -1) {
		switch (c) {
		case 'c':
			DCAPIConfigFile = optarg;
			break;
		default:
			exit(1);
		}
	}

	if (!DCAPIConfigFile) {
		printf("Please specify the DC-API config file!\n");
		exit(1);
	}

	if (DC_initMaster(DCAPIConfigFile)) {
		fprintf(stderr, "Failed to initialise master config file!");
		exit(1);
	}

	DC_setMasterCb(processResult, NULL, NULL);

	submitWU();

	waitForResults();
	
}

static void waitForResults(void) {
	while(assimilatedWUs < maxWus){
		DC_processMasterEvents(600);
	}
}

static void processResult(DC_Workunit *wu, DC_Result *result) {
	
	char *outputFileName, *tag, cmd[256];
	
	tag=DC_getWUTag(wu);	
	
	printf("Result received tag: %s",tag);

	outputFileName = DC_getResultOutput(result, OUT_FILENAME);
	sprintf(cmd,"mv %s %s%s",outputFileName,OUT_FILENAME,tag);
	system(cmd);
	assimilatedWUs++;
	
}

void submitWU() {
	DC_Workunit *wu;
	char wuTag[50];
	const char *arguments[1];
	arguments[0]="wu_script.sh";
	
	sprintf(wuTag,"%d",maxWus);
	wu = DC_createWU("testapp", arguments, 0, wuTag);
	DC_addWUInput(wu, IN_FILENAME, IN_FILENAME, DC_FILE_PERSISTENT);
	DC_addWUOutput(wu, OUT_FILENAME);
	if (DC_submitWU(wu)) {
		DC_log(LOG_ERR, "Failed to submit WU!");
	}
	maxWus++;
}

